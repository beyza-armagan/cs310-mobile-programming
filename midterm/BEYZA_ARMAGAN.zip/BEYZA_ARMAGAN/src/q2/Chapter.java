package q2;

import java.util.ArrayList;
import java.util.List;

public class Chapter {
	private int no;
	private String title;
	private List<Page> pages;
	
	public Chapter() {
		super();
		this.pages = new ArrayList<Page>();
	}
	
	public Chapter(int no, String title, List<Page> pages) {
		super();
		this.no = no;
		this.title = title;
		this.pages = pages;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Page> getPages() {
		return pages;
	}

	public void setPages(List<Page> pages) {
		this.pages = pages;
	}
	
	public String getInfo() {	
		String info = "Chapter: no: " + no + ", title: " + title + "\n";
		
		for (Page page : pages) {
			info += (page.getInfo() + "\n");
		}
		
		return info;
	}

	public int getNumberOfPages() {
		return pages.size();
	}
}
