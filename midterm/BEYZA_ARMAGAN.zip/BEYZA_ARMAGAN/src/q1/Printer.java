package q1;

import java.util.ArrayList;

public abstract class Printer {

	private ArrayList<Printable> docs;
	
	public Printer() {
		super();
		this.docs = new ArrayList<Printable>();
	}

	public abstract void printOut(Printable printable);
	
	public void printAllDocuments() {
		for(Printable doc : docs) {
			printOut(doc);
		}
	}
	
	public void addDocument(Printable printable) {
		docs.add(printable);
	}
}
