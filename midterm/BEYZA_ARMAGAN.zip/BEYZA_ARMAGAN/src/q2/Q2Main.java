package q2;

import java.util.ArrayList;
import java.util.List;

public class Q2Main {
	public static void main(String[] args) { 
		Page page1 = new Page(1, "Page 1 Content");
		Page page2 = new Page(2, "Page 2 Content");
		Page page3 = new Page(3, "Page 3 Content");
		Page page4 = new Page(4, "Page 4 Content");
		
		List<Page> chapter1Pages = new ArrayList<Page>();
		chapter1Pages.add(page1);
		chapter1Pages.add(page2);
		
		Chapter chapter1 = new Chapter(1, "First Chapter", chapter1Pages);
		
		List<Page> chapter2Pages = new ArrayList<Page>();
		chapter2Pages.add(page3);
		chapter2Pages.add(page4);
		
		Chapter chapter2 = new Chapter(2, "Second Chapter", chapter2Pages);
		
		
		List<Chapter> book1Chapters = new ArrayList<Chapter>();
		book1Chapters.add(chapter1);
		Book book1 = new Book("Grapes of Wrath", "Fore word of Grapes Of Wrath", book1Chapters);
		
		List<Chapter> book2Chapters = new ArrayList<Chapter>();
		book2Chapters.add(chapter2);
		Book book2 = new Book("Introduction to Java", "Fore word of Intro to Java", book2Chapters);
		
		
		List<Book> bookShelfBooks = new ArrayList<Book>();
		bookShelfBooks.add(book1);
		bookShelfBooks.add(book2);
		
		BookShelf bookshelf = new BookShelf(bookShelfBooks);
		System.out.println(bookshelf.getInfo());

		Book pickUpBook = bookshelf.pickUpBook(1);
		System.out.println("Pick up book:" + pickUpBook.getInfo());
	}
}
