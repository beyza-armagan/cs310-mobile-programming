package q1;

public class ConsolePrinter extends Printer {

	@Override
	public void printOut(Printable printable) {
		String content = printable.getContent();
		System.out.println("Data is printed to the console: ");
		System.out.println(content);
	}
}
