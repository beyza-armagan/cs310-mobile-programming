package q1;

public interface Printable {
	String getContent();
}
