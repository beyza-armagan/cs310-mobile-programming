package q1;

public class FilePrinter extends Printer {

	private String fileName;
	
	public FilePrinter(String fileName) {
		this.fileName = fileName;
	}
	
	@Override
	public void printOut(Printable printable) {
		String content = printable.getContent();
		System.out.println("Data printed to file: " + fileName + " : ");
		System.out.println(content);
	}
}
