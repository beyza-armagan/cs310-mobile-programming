package q1;

import java.time.LocalDateTime;

public class Q1Main {
	public static void main(String[] args) { 
		
		Report report = getReport();
		SpreadSheet spreadSheet = getSpreadSheet();
		Letter letter = getLetter();
		
		FilePrinter filePrinter = new FilePrinter("output1.txt");
		filePrinter.addDocument(report);
		filePrinter.addDocument(spreadSheet);
		filePrinter.addDocument(letter);
		
		ConsolePrinter consolePrinter = new ConsolePrinter();
		consolePrinter.addDocument(report);
		consolePrinter.addDocument(spreadSheet);
		consolePrinter.addDocument(letter);
		
		filePrinter.printAllDocuments();
		consolePrinter.printAllDocuments();
	}
	
	private static Report getReport() {
		String reportTitle = "Final Exam";
		LocalDateTime reportDate = LocalDateTime.now();
		String reportText = "I am trying to complete the question, yeah still!";
		
		Report report = new Report(reportTitle, reportText, reportDate);
		return report;
	}
	
	private static SpreadSheet getSpreadSheet() {
		String subject = "Budget";
		int numberOfColumns = 10;
		int numberOfRows = 10;
		
		SpreadSheet spreadSheet = new SpreadSheet(subject, numberOfColumns, numberOfRows);
		return spreadSheet;
	}
	
	private static Letter getLetter() {
		String sender = "Jack";
		String receiver = "Henry";
		String textContent = "Letter content";
		
		Letter letter = new Letter(sender, receiver, textContent);
		return letter;
	}
}

