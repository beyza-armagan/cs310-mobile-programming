package q1;

public class Letter implements Printable {

	private String sender;
	private String receiver;
	private String textContent;
	
	public Letter(String sender, String receiver, String textContent) {
		super();
		this.sender = sender;
		this.receiver = receiver;
		this.textContent = textContent;
	}

	@Override
	public String getContent() {
		return toString();
	}

	@Override
	public String toString() {
		return "Letter [sender=" + sender + ", receiver=" + receiver + ", textContent=" + textContent + "]";
	}
}
