package q2;

import java.util.ArrayList;
import java.util.List;

public class Book {

	private String title;
	private String foreWord;
	private List<Chapter> chapters;
	
	public Book() {
		super();
		this.chapters = new ArrayList<Chapter>();
	}
	
	public Book(String title, String foreWord, List<Chapter> chapters) {
		super();
		this.title = title;
		this.foreWord = foreWord;
		this.chapters = chapters;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getForeWord() {
		return foreWord;
	}

	public void setForeWord(String foreWord) {
		this.foreWord = foreWord;
	}

	public List<Chapter> getChapters() {
		return chapters;
	}

	public void setChapters(List<Chapter> chapters) {
		this.chapters = chapters;
	}
	
	public String getInfo() {
		String info = "Book: title: " + title + ", foreWord: " + foreWord + "\n" + "Total number of pages: " + getNumberOfPages() + "\n";
		
		for (Chapter chapter : chapters) {
			info += (chapter.getInfo() + "\n");
		}
		
		return info;
	}

	public int getNumberOfPages() {
		int totalNumberOfPages = 0;
		for (Chapter chapter : chapters) {
			totalNumberOfPages += chapter.getNumberOfPages();
		}
		
		return totalNumberOfPages;
	}
}
