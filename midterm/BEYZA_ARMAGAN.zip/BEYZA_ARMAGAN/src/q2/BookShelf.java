package q2;

import java.util.ArrayList;
import java.util.List;

public class BookShelf {

	private List<Book> books;

	public BookShelf() {
		super();
		this.books = new ArrayList<Book>();
	}
	
	public BookShelf(List<Book> books) {
		super();
		this.books = books;
	}

	public List<Book> getBooks() {
		return books;
	}

	public void setBooks(List<Book> books) {
		this.books = books;
	}

	public String getInfo() {
		String info = "Bookshelf: \nTotal number of books: " + getNumberOfBooks() + "\n\n";
		
		for (Book book : books) {
			info += (book.getInfo() + "\n");
		}
		
		return info;
	}
	
	
	public Book pickUpBook(int index) {
		if (books == null || index > books.size() - 1) {
			return null;
		}
		
		return books.get(index);
	}
	
	public int getNumberOfPages() {
		int totalNumberOfPages = 0;
		for (Book book : books) {
			totalNumberOfPages += book.getNumberOfPages();
		}
		
		return totalNumberOfPages;
	}
	
	public int getNumberOfBooks() {
		if (books == null) {
			return 0;
		}
		
		return books.size();
	}
	
	
}
